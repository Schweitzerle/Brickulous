package com.example.brickulous;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.brickulous.Api.APIRequests;
import com.example.brickulous.Api.GetSetByNumberData;
import com.example.brickulous.Api.GetSetByNumberNoAdapterData;
import com.example.brickulous.Api.LegoSetData;
import com.example.brickulous.Fragments.HomeFragment;

public class ItemDetailActivity extends AppCompatActivity {

    public static final String SET_NUMBER_KEY = "SET NUMBER";

    RecyclerView recyclerView;

    TextView setNumber, setName, year, numberOfPieces, themeID, setURL;
    ImageView setImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);
        initUI();
    }

    private void initUI() {
        recyclerView = findViewById(R.id.recycler);
        String setNumberString = getIntent().getStringExtra(SET_NUMBER_KEY);
        GetSetByNumberNoAdapterData getSetByNumberData = new GetSetByNumberNoAdapterData(getApplicationContext(), recyclerView, APIRequests.GET_SET.getURL() + setNumberString + HomeFragment.API_KEY);
        getSetByNumberData.execute();
    }
}