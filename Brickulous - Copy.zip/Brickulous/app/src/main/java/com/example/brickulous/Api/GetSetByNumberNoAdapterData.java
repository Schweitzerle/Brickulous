package com.example.brickulous.Api;

import android.content.Context;
import android.os.AsyncTask;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.brickulous.Adapter.SetAdapter;
import com.example.brickulous.Adapter.SetDetailAdapter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class GetSetByNumberNoAdapterData extends AsyncTask<String, String, String> {

    RecyclerView recyclerView;
    Context context;
    String urlString;
    LegoSetData legoSetDataPut;


    public GetSetByNumberNoAdapterData(Context context, RecyclerView recyclerView, String urlString) {
        this.context = context;
        this.urlString = urlString;
        this.recyclerView = recyclerView;
    }

    @Override
    protected String doInBackground(String... strings) {
        String current = "";

        try {
            URL url;
            HttpURLConnection urlConnection = null;

            try {
                url = new URL(urlString);
                urlConnection = (HttpURLConnection) url.openConnection();

                InputStream is = urlConnection.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);

                int data = isr.read();
                while (data != -1) {
                    current += (char) data;
                    data = isr.read();
                }
                return current;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return current;

    }

    @Override
    protected void onPostExecute(String s) {
        try {
            JSONObject jsonObject1 = new JSONObject(s);

            LegoSetData legoSetData = new LegoSetData();
            legoSetData.setSetNumb(jsonObject1.getString("set_num"));
            legoSetData.setName(jsonObject1.getString("name"));
            legoSetData.setImageURL(jsonObject1.getString("set_img_url"));
            legoSetData.setNumbOfParts(jsonObject1.getInt("num_parts"));
            legoSetData.setYear(jsonObject1.getInt("year"));
            legoSetData.setSetURL(jsonObject1.getString("set_url"));
            legoSetData.setThemeID(jsonObject1.getInt("theme_id"));

            legoSetDataPut = legoSetData;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        putDataToRecycler(legoSetDataPut);
    }

    private void putDataToRecycler(LegoSetData legoSetData) {
        SetDetailAdapter setDetailAdapter = new SetDetailAdapter(context, legoSetData);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));
        recyclerView.setAdapter(setDetailAdapter);
    }
}
